package com.sprint.mission.discodeit.service;

public interface BasicService {

    void process(String data);
}
