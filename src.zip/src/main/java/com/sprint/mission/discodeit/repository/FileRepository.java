package com.sprint.mission.discodeit.repository;

public interface FileRepository {

    void save(String data);

}
